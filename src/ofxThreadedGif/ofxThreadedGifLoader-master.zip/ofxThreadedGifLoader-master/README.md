# ofxThreadedGifLoader
An addon for loading gif animations with threading

## thanks to
- [jesusgollonet/ofxGifEncoder](https://github.com/jesusgollonet/ofxGifEncoder)

## License
MIT
